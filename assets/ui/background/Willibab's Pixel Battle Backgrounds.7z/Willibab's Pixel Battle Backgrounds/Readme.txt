
Creator: Willibab - https://willibab.itch.io/
Preview Sprites: The Mighty Palm - itch.io
Preview Font: Mounir Tohami - itch.io

Socials: https://twitter.com/Monsteretrope
Follow me to see new sprites or make suggestions!

LICENSE:

- Free to Use in Personal and Commercial Projects. 
- Free to Edit or Modify Assets. - Credit Willibab. 
- CANNOT resell these assets. 
- CANNOT claim assets as your own.